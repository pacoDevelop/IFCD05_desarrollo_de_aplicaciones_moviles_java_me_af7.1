package com.modelo;

public interface IUsuarios_Fachada {

	Usuarios consultar_PorNombre(String nombre_usuario);

}