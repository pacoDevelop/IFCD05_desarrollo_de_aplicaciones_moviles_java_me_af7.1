package com.modelo.dao;

public class Tareas_DAO extends Abstract_DAO{

	
}
