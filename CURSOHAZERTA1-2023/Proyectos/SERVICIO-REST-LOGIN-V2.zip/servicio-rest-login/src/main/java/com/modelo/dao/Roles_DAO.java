package com.modelo.dao;

public class Roles_DAO extends Abstract_DAO{

}
