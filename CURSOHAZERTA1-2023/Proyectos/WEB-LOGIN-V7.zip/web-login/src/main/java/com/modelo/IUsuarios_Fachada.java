package com.modelo;

import java.util.List;

public interface IUsuarios_Fachada {

	Usuarios consultar_PorNombre(String nombre_usuario);

	List<Tareas> consultar_TareasUsuario(Usuarios usuario_logado);

}