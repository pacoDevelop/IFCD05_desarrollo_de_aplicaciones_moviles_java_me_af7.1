package com.modelo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Named;

/**
 * DAO de acceso a la tabla de Usuarios.
 * 
 * @author jsolv @ since 13-1-2023.
 */
@Named("usuario-dao")
public class Usuario_DAO implements IUsuario_DAO {

	/**
	 * Proceso de consulta de la base de datos por la clave primaria de la tabla.
	 * 
	 * @param nombre_usuario
	 * @return
	 */
	@Override
	public Usuarios consultar_PorNombre(String nombre_usuario) {
		Usuarios usuario_consultado = null;
		// SIMULACION DEL RESULTADO DE LA CONSULTA
		if (nombre_usuario.equals("Juan")) {
			usuario_consultado = new Usuarios();
			usuario_consultado.setNombreUsuario("Juan");
			usuario_consultado.setPassword("admin");
			usuario_consultado.setFechaAlta(new Date());
//			usuario_consultado.setRol("1");
		}
		return usuario_consultado;
	}

	/**
	 * Proceso de consulta de las tareas que puede realizar un usuario concreto
	 * 
	 * @param usuario_logado
	 * @return
	 */
	@Override
	public List<Tareas> consultar_TareasUsuario(Usuarios usuario_logado) {
		List<Tareas> tareas_consultadas = new ArrayList<Tareas>();
		// falta simulacion proceso
		
		
		return tareas_consultadas;
	}

}
