package com.modelo;

import java.util.HashSet;
import java.util.Set;
/**
 * DTO de la tabla de tareas.
 * @author jsolv
 *
 */
public class Tareas implements java.io.Serializable {

	// Fields
	private Byte codigoTarea;
	private String descripcionTarea;
	private String vinculo;
	
	// Constructors
	/** default constructor */
	public Tareas() {
	}

	/** minimal constructor */
	public Tareas(Byte codigoTarea) {
		this.codigoTarea = codigoTarea;
	}

	/** full constructor */
	public Tareas(Byte codigoTarea, String descripcionTarea, String vinculo) {
		this.codigoTarea = codigoTarea;
		this.descripcionTarea = descripcionTarea;
		this.vinculo = vinculo;
	}

	public Byte getCodigoTarea() {
		return this.codigoTarea;
	}

	public void setCodigoTarea(Byte codigoTarea) {
		this.codigoTarea = codigoTarea;
	}

	public String getDescripcionTarea() {
		return this.descripcionTarea;
	}

	public void setDescripcionTarea(String descripcionTarea) {
		this.descripcionTarea = descripcionTarea;
	}

	public String getVinculo() {
		return this.vinculo;
	}

	public void setVinculo(String vinculo) {
		this.vinculo = vinculo;
	}
	
}