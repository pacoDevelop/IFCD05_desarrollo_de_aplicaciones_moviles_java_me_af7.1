package com.managedbean;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import com.modelo.Usuario;


@ManagedBean(name="usuarios_bean")
@ViewScoped
public class DataTable_Bean {
	// COLECCION DONDE SE ALMACENARAN LOS DATOS A MOSTRAR
	private List<Usuario> lista_usuarios;

	
	
	// ACCESORES PARA JSF
	public List<Usuario> getLista_usuarios() {
		return lista_usuarios;
	}

	public void setLista_usuarios(List<Usuario> lista_usuarios) {
		this.lista_usuarios = lista_usuarios;
	}
	
}
