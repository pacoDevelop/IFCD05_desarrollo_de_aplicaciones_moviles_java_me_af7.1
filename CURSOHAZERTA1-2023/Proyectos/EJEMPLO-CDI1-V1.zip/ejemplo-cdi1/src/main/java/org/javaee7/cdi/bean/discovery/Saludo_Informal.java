package org.javaee7.cdi.bean.discovery;

@Informal
public class Saludo_Informal implements Greeting{

	@Override
	public String greet(String name) {
		return "Hola muchacho "+name;
	}

}
