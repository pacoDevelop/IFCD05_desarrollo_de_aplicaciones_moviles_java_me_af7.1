package com.modelo;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * Fachada de acceso a los procesos de la tabla Usuarios.
 * 
 * @author jsolv
 *
 */
@Named("fachada_usuarios")
public class Usuarios_Fachada implements IUsuarios_Fachada {
	@Inject
	@Named("usuario-dao")
	private IUsuario_DAO usuario_dao;
	
	public Usuarios_Fachada() {
		usuario_dao = new Usuario_DAO();
	}

	@Override
	public Usuarios consultar_PorNombre(String nombre_usuario) {
		Usuarios usuario_consultado = null;
		usuario_consultado = usuario_dao.consultar_PorNombre(nombre_usuario);
		return usuario_consultado;
	}

	@Override
	public List<Tareas> consultar_TareasUsuario(Usuarios usuario_logado) {
		List<Tareas> tareas_consultadas = usuario_dao.consultar_TareasUsuario(usuario_logado);
		return tareas_consultadas;
	}

}
