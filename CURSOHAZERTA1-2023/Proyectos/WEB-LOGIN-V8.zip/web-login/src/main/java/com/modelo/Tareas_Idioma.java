package com.modelo;


/**
 * Extension de la clase de persistencia Tareas para incluir la traduccion del
 * texto a mostrar en el menu personalizado.
 * 
 * @author Juan Antonio Solves Garcia.
 * @version 1.8
 * @since 25-05-2023.
 */
public class Tareas_Idioma extends Tareas {

	private String traduccion;

	//ACCESORES PARA LOS DATOS
	public String getTraduccion() {
		return traduccion;
	}

	public void setTraduccion(String traduccion) {
		this.traduccion = traduccion;
	}
}
