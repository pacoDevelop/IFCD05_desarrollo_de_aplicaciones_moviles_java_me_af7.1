package com.modelo;

import java.util.HashSet;
import java.util.Set;
/**
 * DTO de la tabla roles en la base de datos.
 * @author jsolv
 *
 */
public class Roles implements java.io.Serializable {
	// Fields
	private Byte codigoRol;
	private String descripcionRol;
	// REPRESENTACION DE LA RELACION ENTRE ROLES-TAREAS
	private Set<Tareas> tareases = new HashSet<Tareas>(0);

	// Constructors
	/** default constructor */
	public Roles() {
	}

	/** minimal constructor */
	public Roles(Byte codigoRol) {
		this.codigoRol = codigoRol;
	}

	/** full constructor */
	public Roles(Byte codigoRol, String descripcionRol, Set<Tareas> tareases) {
		this.codigoRol = codigoRol;
		this.descripcionRol = descripcionRol;
		this.tareases = tareases;
	}

	public Byte getCodigoRol() {
		return this.codigoRol;
	}

	public void setCodigoRol(Byte codigoRol) {
		this.codigoRol = codigoRol;
	}

	public String getDescripcionRol() {
		return this.descripcionRol;
	}

	public void setDescripcionRol(String descripcionRol) {
		this.descripcionRol = descripcionRol;
	}

	public Set<Tareas> getTareases() {
		return this.tareases;
	}

	public void setTareases(Set<Tareas> tareases) {
		this.tareases = tareases;
	}

}