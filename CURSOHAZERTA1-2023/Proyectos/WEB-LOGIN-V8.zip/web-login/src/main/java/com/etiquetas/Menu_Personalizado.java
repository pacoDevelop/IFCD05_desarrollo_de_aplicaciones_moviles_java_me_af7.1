package com.etiquetas;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.modelo.IUsuarios_Fachada;
import com.modelo.Tareas;
import com.modelo.Tareas_Idioma;
import com.modelo.Usuarios;
import com.modelo.Usuarios_Fachada;

/**
 * Etiqueta personalizada para la generacion dinamica del menu personalizado de
 * cada usuario que inicia la aplicacion.
 * 
 * @author Juan Antonio Solves Garcia.
 * @version 2.1.
 * @since 25-01-2023.
 */
public class Menu_Personalizado extends SimpleTagSupport implements Comparator<Tareas_Idioma> {
	// PROPIEDAD PARA RECOGER EL ATRIBUTO DE LA ETIQUETA
	private boolean sentido;

	// COLECCION PARA IDIOMATIZAR LAS OPCIONES DE MENU
	private List<Tareas_Idioma> lista_tareas_traducidas;
	private ResourceBundle rb;
	private String idioma_elegido;
	private Usuarios usuario_logado;
	// CAPA MODELO
//	@Inject
//	@Named("fachada_usuarios")
	private IUsuarios_Fachada usuario_fachada;

	public Menu_Personalizado() {
		usuario_fachada = new Usuarios_Fachada();
	}

	@Override
	public void doTag() throws JspException, IOException {
		// RECOGEMOS EL USUARIO DE LA SESION
		usuario_logado = (Usuarios) this.getJspContext().getAttribute("usuario", PageContext.SESSION_SCOPE);
		// EJECUCION DE PROCESO SOLO EN CASO DE QUE EXISTA EL USUARIO
		if (usuario_logado != null) {
			creacion_Menu();
		} else {
			// OPCION SIN IMPLEMENTAR
			// CUBRIRIA EL MENU DE LAS OPCIONES PUBLICAS PARA USUARIOS ANONIMOS
			// SIN USO EN ESTA APLICACION
		}
	}

	/**
	 * Inicio del proceso de creacion del menu dinamico para la aplicacion.
	 * 
	 * @throws IOException
	 */
	private void creacion_Menu() throws IOException {
		// RECOGEMOS LA LISTA DE TAREAS DE LA SESSION SI ES QUE ESTA
		lista_tareas_traducidas = (List<Tareas_Idioma>) this.getJspContext().getAttribute("lista_tareas",
				PageContext.SESSION_SCOPE);
		// AVERIGUAMOS EL IDIOMA PREFERIDO DEL USUARIO
		idioma_elegido = (String) this.getJspContext().getAttribute("idioma_elegido", PageContext.SESSION_SCOPE);
		// RESOLVEMOS LA IDIOMATIZACION DEL MENU
		rb = ResourceBundle.getBundle(idioma_elegido);
		// PROCESAMOS LA CONSULTA SOLO LA PRIMERA VEZ
		if (lista_tareas_traducidas == null) {
			// PEDIMOS LAS TAREAS DEL USUARIO
			this.obtener_Tareas();
		}
		// RECOGEMOS EL IDIOMA ANTERIOR, SI LO HAY, Y COMPARAMOS CON EL NUEVO
		String idioma_anterior = (String) this.getJspContext().getAttribute("idioma_anterior",
				PageContext.SESSION_SCOPE);
		if (!idioma_elegido.equals(idioma_anterior) && lista_tareas_traducidas != null) {
			// SE TRADUCE EL MENU AL NUEVO IDIOMA
			this.traducir_Menu();
		}
		// LLAMAMOS A LA GENERACION DEL MENU
		this.generar_Menu();
	}

	/**
	 * Proceso dinamico de consulta a la base de datos para la obtencion de las
	 * tareas de cada usuario y la creacion de la traduccion a usar a partir de las
	 * mismas.</br>
	 * Este proceso solo se ejecutara en la primera peticion del usuario, despues
	 * del login correcto, en cada sesion.
	 */
	private void obtener_Tareas() {
		// CREAMOS POR PRIMERA VEZ LA COLECCION DE TAREAS TRADUCIDAS
		lista_tareas_traducidas = new ArrayList<Tareas_Idioma>();
		// REALIZO LA CONSULTA QUE ME RESUELVE LA CARGA VAGA DE HIBERNATE
		List<Tareas> lista_tareas = usuario_fachada.consultar_TareasUsuario(usuario_logado);
		// A�ADADIMOS LA TRADUCCION A LAS TAREAS SI EL USUARIO LAS TIENE
		if (lista_tareas.size() > 0) {
			// CARGAMOS LA TRADUCCION DE LAS TAREAS
			Tareas_Idioma nueva_tarea_traducida;
			for (Tareas tarea : lista_tareas) {
				nueva_tarea_traducida = new Tareas_Idioma();
				// CARGAMOS LOS DATOS DE LA TAREA A LA TAREA TRADUCIDA
				nueva_tarea_traducida.setCodigoTarea(tarea.getCodigoTarea());
				nueva_tarea_traducida.setDescripcionTarea(tarea.getDescripcionTarea());
				nueva_tarea_traducida.setVinculo(tarea.getVinculo());
				// METEMOS LA TRADUCCION LEYENDO DEL PROPERTIES
				nueva_tarea_traducida.setTraduccion(
						rb.getString("menu.opcion." + tarea.getDescripcionTarea().toLowerCase().replace(" ", "")));
				// GUARDAMOS LA TAREA TRADUCIDA EN SU PROPIA COLECCION
				lista_tareas_traducidas.add(nueva_tarea_traducida);
			}
			// ORDENAMOS LA COLECCION POR LA TRADUCCION DEL TEXTO
			Collections.sort(lista_tareas_traducidas, this);
		} else {
			// CASO DE USUARIO SIN ROL ASIGNADO O ROL SIN TAREAS
			// SIN IMPLEMENTAR
		}
		// CARGAMOS LA LISTA DE TAREAS PARA QUE EN UNA NUEVA PETICION NO SE
		// REPITA EL PROCESO
		this.getJspContext().setAttribute("lista_tareas", lista_tareas_traducidas, PageContext.SESSION_SCOPE);
		// BANDERA PARA PROCESAR EL CAMBIO DE IDIOMA
		this.getJspContext().setAttribute("idioma_anterior", idioma_elegido, PageContext.SESSION_SCOPE);
	}

	/**
	 * Proceso de traduccion del menu al nuevo idioma seleccionado.</br>
	 * Este proceso se ejecutara tantas veces como el usuario cambie de idioma en su
	 * sesion.
	 */
	private void traducir_Menu() {
		// CARGAMOS LA TRADUCCION DE LAS TAREAS
		for (Tareas_Idioma tarea : lista_tareas_traducidas) {
			tarea.setTraduccion(
					rb.getString("menu.opcion." + tarea.getDescripcionTarea().toLowerCase().replace(" ", "")));
		}
		// ORDENAMOS LA COLECCION POR LA TRADUCCION DEL TEXTO
		Collections.sort(lista_tareas_traducidas, this);
		// CARGAMOS LA LISTA DE TAREAS PARA QUE EN UNA NUEVA PETICION NO SE
		// REPITA EL PROCESO
		this.getJspContext().setAttribute("lista_tareas", lista_tareas_traducidas, PageContext.SESSION_SCOPE);
		this.getJspContext().setAttribute("idioma_anterior", idioma_elegido, PageContext.SESSION_SCOPE);
	}

	/**
	 * Proceso interno de creacion del HTML para el menu del usuario.
	 * 
	 * @throws IOException Excepcion producida por el proceso de escritura en la
	 *                     pagina.
	 */
	private void generar_Menu() throws IOException {
		// GENERACION DEL HTML PARA LA PAGINA
		StringBuffer salida = new StringBuffer();
		String descripcion = "";
		// TRATO EL RESULTADO DE LA CONSULTA PARA CREAR EL HTML NECESARIO
		for (Tareas_Idioma tarea : lista_tareas_traducidas) {
			descripcion = tarea.getTraduccion();
			// CREACION DE LOS HIPERVINCULOS DEL MENU
			salida.append("\n<tr><td><a href='jsp/principal.jsp?tarea=" + tarea.getVinculo() + "'>" + descripcion
					+ "</a></td></tr>");
		}
		// ESCRIBO EL HTML EN LA PAGINA
		this.getJspContext().getOut().append(salida.toString());
	}

	/**
	 * Proceso de ordenacion de los textos, en el idioma seleccionado, de la
	 * coleccion para ser mostrados en el menu.
	 */
	@Override
	public int compare(Tareas_Idioma tarea1, Tareas_Idioma tarea2) {
		int comparacion = 0;
		if (new Boolean(isSentido())) {
			comparacion = tarea1.getTraduccion().compareTo(tarea2.getTraduccion());
		} else {
			comparacion = tarea2.getTraduccion().compareTo(tarea1.getTraduccion());
		}
		return comparacion;
	}

	// ACCESORES PARA RECIBIR LOS VALORES DE LA PAGINA
	public void setSentido(boolean sentido) {
		this.sentido = sentido;
	}

	public boolean isSentido() {
		return sentido;
	}

}
