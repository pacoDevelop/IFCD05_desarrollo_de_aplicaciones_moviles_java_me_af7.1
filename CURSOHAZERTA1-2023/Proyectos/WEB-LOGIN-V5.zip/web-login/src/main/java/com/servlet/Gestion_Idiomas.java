package com.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Gestion_Idiomas
 * Gestion de cambio de idioma por parte del usuario.
 * 
 * @author Juan Antonio Solves Garcia.
 * @version 2.0.
 */
@WebServlet(description = "Cambio dinamico del idioma por parte del usuario", urlPatterns = { "/Gestion_Idiomas" })
public class Gestion_Idiomas extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Proceso de cambio del idioma preferido por parte del usuario.
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest peticion, HttpServletResponse respuesta)
			throws ServletException, IOException {
		// RECOGEMOS EL NUEVO IDIOMA PREFERIDO
		String idioma_seleccionado = "com/idiomas/textos_" + peticion.getParameter("idioma");
		// MODIFICAMOS EL ATRIBUTO DE SESION PARA EL IDIOMA
		peticion.getSession().setAttribute("idioma_elegido", idioma_seleccionado);
		// VOLVEMOS A LA PAGINA DEL PORTAL
		RequestDispatcher rqd = peticion
				.getRequestDispatcher("jsp/principal.jsp?tarea=" + peticion.getParameter("tarea"));
		rqd.forward(peticion, respuesta);
	}

}
